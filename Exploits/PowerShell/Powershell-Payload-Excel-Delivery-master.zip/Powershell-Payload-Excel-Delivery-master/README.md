New-Powershell-Payload-Excel-Delivery
=====================================

This is a VBA macro that uses Matt Graeber's Invoke-Shellcode to execute a powershell payload in memory as well as 
schedule a task for persistence.

Please note that the powershell commands in the macro can be encoded.

For this to work, Invoke-Shellcode needs to be accessible by the target.

HUGE thanks to Matthew Graeber (@mattifestation) for writing Invoke-Shellcode. You can find his great work over at 
https://github.com/mattifestation. 


